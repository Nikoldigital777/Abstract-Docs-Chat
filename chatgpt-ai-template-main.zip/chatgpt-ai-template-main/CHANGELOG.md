# Changelog

## [2.2.0] 2024-07-19

### Vulnerabilities removed

## [2.1.0] 2024-06-28

### GPT-4o Support

Updated GPT-3.5-Turbo to GPT-4o

## [2.0.0] 2024-02-06

### Next 14

Updated Next

## [1.0.0] 2023-06-20

### Official Release

Added TypeScript & NextJS
